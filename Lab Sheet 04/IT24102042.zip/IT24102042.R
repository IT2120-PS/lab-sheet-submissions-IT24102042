setwd("C:\\Users\\IT24102042\\Desktop\\IT24102042_lab2")

sum(1.15 %% 3 == 0)

v <- c(5,3,9,10,4)
max_index <- 1
max_value <- v[1]

for (i in 2:length(v)){
  if (v[i] > max_value){
    max_value <- v[i]
    max_index <- i
  }
}
print(max_index)

v <- c(5,3,9,2,10,4)
which.max(v)